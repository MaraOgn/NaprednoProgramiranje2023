#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
using namespace std;
struct Profil {
    int IDbroj;
    string Nickname;
    float nivo;
};

bool compareByNickname(const Profil& a, const Profil& b) {
    return a.Nickname < b.Nickname;
}

int main() {
    vector<Profil> profilVector;

    // Додавање на записи во векторот
    Profil p1 = { 1, "Marija Ognenovska", 3.2 };
    Profil p2 = { 2, "Ivana Mitrevska", 2.5 };
    Profil p3 = { 3, "David Dimovski", 4.1 };
    Profil p4 = { 4, "Hristijan Petrovski", 1.7 };
    Profil p5 = { 5, "Hristijan Mizimakovski", 3.9 };

    profilVector.push_back(p1);
    profilVector.push_back(p2);
    profilVector.push_back(p3);
    profilVector.push_back(p4);
    profilVector.push_back(p5);

    // Испечати содржина на векторот пред сортирањето
    cout << "Sodrzina na vektorot pred sortiranjeto:" << endl;
    for (const auto& profil : profilVector) {
        cout << "ID: " << profil.IDbroj << ", Nickname: " << profil.Nickname << ", Nivo: " << profil.nivo << endl;
    }
    cout << endl;

    // Сортирање на векторот по Nickname
    sort(profilVector.begin(), profilVector.end(), compareByNickname);

    // Испечати содржина на векторот по сортирањето
    cout << "Sodrzina na vektorot pred sortiranjeto" <<endl;
    for (const auto& profil : profilVector) {
        cout << "ID: " << profil.IDbroj << ", Nickname: " << profil.Nickname << ", Nivo: " << profil.nivo <<endl;
    }

    // Зачувај ја содржината на векторот во излезната датотека
    ofstream outputFile("INKI948.Marija");
    if (outputFile.is_open()) {
        for (const auto& profil : profilVector) {
            outputFile << "ID: " << profil.IDbroj << ", Nickname: " << profil.Nickname << ", Nivo: " << profil.nivo <<endl;
        }
        outputFile.close();
        cout << "Sodrzinata e zacuvana vo fajlot INKI948.Marija" <<endl;
    }
    else {
    cout << "Ne moze da se sozdade izlezna datoteka." << endl;
    }

    return 0;
}
