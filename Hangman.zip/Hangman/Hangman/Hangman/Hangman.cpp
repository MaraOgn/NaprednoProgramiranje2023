﻿#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <string>
#include <windows.h>

using namespace std;

string randomWord(string fileName);
void drawHangman(int tries);
void printWord(string word, string guessed);

int main()
{
    SetConsoleOutputCP(CP_UTF8); // поставување на кодната табела за излезот на UTF-8 за прикажување на кирилични знаци

    string fileName = "words.txt";
    string wordToGuess = randomWord(fileName);

    string guessed(wordToGuess.length(), '-');
    int tries = 0;

    while (tries < 6 && guessed != wordToGuess)
    {
        system("cls");
        cout << "Играта е Виселица!" << endl << endl;
        printWord(wordToGuess, guessed);

        cout << endl << endl << "Внесете буква: ";
        char guess;
        cin >> guess;
        guess = tolower(guess); // претворање на внесената буква во мали букви
        bool found = false;
        for (int i = 0; i < wordToGuess.length(); i++)
        {
            if (wordToGuess[i] == guess)
            {
                guessed[i] = guess;
                found = true;
            }
        }
        if (!found)
        {
            tries++;
        }
    }

    system("cls");
    if (guessed == wordToGuess)
    {
        cout << "ПОБЕДА! Зборот беше " << wordToGuess << "." << endl;
    }
    else
    {
        drawHangman(tries);
        cout << endl << endl << "ИЗГУБИ! Зборот беше " << wordToGuess << "." << endl;
    }
    system("pause");
    return 0;
}

// Функција за случајно избирање на збор од фајл со зборови
string randomWord(string fileName)
{
    ifstream file(fileName.c_str());
    string word;
    int count = 0;
    while (file >> word)
    {
        count++;
    }
    srand(time(NULL));
    int randomIndex = rand() % count;
    file.clear();
    file.seekg(0);
    for (int i = 0; i < randomIndex; i++)
    {
        file >> word;
    }
    file.close();
    return word;
}

// Функција за цртање на сликата на виселицата во зависност од бројот на обиди на играчот
void drawHangman(int tries)
{
    cout << "  +-----+" << endl;
    cout << "  |     |" << endl;
    if (tries >= 1)
    {
        cout << "  O     |" << endl;
    }
    else
    {
        cout << "        |" << endl;
    }
    if (tries >= 2)
    {
        if (tries == 2)
        {
            cout << "  |     |" << endl;
        }
        else if (tries == 3)
        {
            cout << " /| |" << endl;
        }
        else
        {
            cout << " |" << endl;
            cout << " |" << endl;
        }
        if (tries >= 4)
        {
            if (tries == 4)
            {
                cout << " | |" << endl;
            }
            else if (tries == 5)
            {
                cout << " / |" << endl;
            }
            else
            {
                cout << " / \ |" << endl;
            }
        }
        else
        {
            cout << " |" << endl;
            cout << " |" << endl;
        }
        cout << "=========" << endl;
    }

    // Функција за печатење на зборот и буквите кои играчот ги погоди
    void printWord(string word, string guessed)
    {
        for (int i = 0; i < guessed.length(); i++)
        {
            if (guessed[i] == '-')
            {
                cout << "_";
            }
            else
            {
                cout << guessed[i];
            }
            cout << " ";
        }
        cout << endl;
    }

